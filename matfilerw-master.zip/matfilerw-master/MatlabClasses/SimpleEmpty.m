classdef SimpleEmpty
    %SIMPLEEMPTY A simple empty class definition.
    
    properties
    end
    
    methods
    end
    
end

