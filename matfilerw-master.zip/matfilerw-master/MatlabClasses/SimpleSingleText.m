classdef SimpleSingleText
    %SIMPLESINGLETEXT Summary of this class goes here
    %   Detailed explanation goes here
    
    properties
        test_text = 'Default text'
    end
    
    methods
    end
    
end

